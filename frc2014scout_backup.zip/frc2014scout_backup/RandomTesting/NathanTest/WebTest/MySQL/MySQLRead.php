<!DOCTYPE html>
<html>
    <head>
        <title>MySQL Test - Read Data</title>
    </head>
    <body>
        <h3>Write to HTML</h3>
        <form action="MySQLWriteFile.php" method="POST">
            <input type="text" name="database" placeholder="database"><br/>
            <input type="text" name="table" placeholder="table"><br/>
            <input type="text" name="field1" placeholder="field1"><br/>
            <input type="text" name="field2" placeholder="field2"><br/>
            <input type="text" name="field3" placeholder="field3"><br/>
            <button>Write File</button>
        </form>
    </body>
</html>
