<?php
    $databaseID = "yashamos";
    $databaseUser = "yashamos_nathan";
    $databasePassword = "nathan123";