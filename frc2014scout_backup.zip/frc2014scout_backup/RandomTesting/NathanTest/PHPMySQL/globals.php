<?php
$GLOBALS['username']="username";//TODO: set the global variables to your server info
$GLOBALS['password']="pass";
$GLOBALS['database']="databasename";
$GLOBALS['server']="sql.server";


/*$username=$GLOBALS['username'];
$password=$GLOBALS['password'];
$database=$GLOBALS['database'];
$server=$GLOBALS['server'];*/
?>