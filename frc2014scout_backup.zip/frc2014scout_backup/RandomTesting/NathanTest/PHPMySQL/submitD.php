<?php
session_start();//junk code
var_dump($_POST);
echo '<br/>';
var_dump($_SESSION);
?>