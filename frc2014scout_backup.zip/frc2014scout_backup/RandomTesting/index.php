<!DOCTYPE HTML PUBLIC "-//W3C/DTD HTML 4.01>

<html>
    <body>
        <?php
        echo "Hello, world! This is my first PHP project!";
        ?>
    </body>
</html>
      